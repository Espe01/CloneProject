Created main module for testing new functions.
Created ConvertToWav module for testing the functionality of converting audio files to wav files and handling multiple channels.
Created RemoveMetaData module for testing the functionality of removing metadata from audio files.
Created DataAnalysis module for testing the functionality of scanning the wav file for frequencies and plotting those frequencies.
Created Controller module for running the flow of the application.
Created the Model module for holding and manipulating state information in the application.
Created the View module for presenting data to the user.
Consolodated functions within the ConvertToWav, RemoveMetaData, and DataAnalysis modules down into their proper places within the Controller, Model, and View modules.
Added setup.cfg with functionality for changing the base window size of the gui.