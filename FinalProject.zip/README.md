This project allows a user to import an audio file for cleaning, data analysis, modeling, and reporting.
Use the "Load Audio File" button to select an audio file.
After loading an audio file use the "View Spectragram" button to view the audio files spectragram.
After loading an audio file use the "Switch" button to switch between viewing the high, mid, and low RT60 graphs for the audio file.
After loading an audio file use the "Combine Figures" button to combine the high, mid, and low RT60 graphs into a single graph.